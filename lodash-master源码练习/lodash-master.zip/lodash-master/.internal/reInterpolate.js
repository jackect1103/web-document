/** Used to match template delimiters. */
const reInterpolate = /<%=([\s\S]+?)%>/g

export default reInterpolate
